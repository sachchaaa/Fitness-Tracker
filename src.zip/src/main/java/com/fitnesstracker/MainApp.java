package com.fitnesstracker;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
// Load the FXML layout
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/com/fitness/MainView.fxml")
        );
        Parent root = loader.load();

        Scene scene = new Scene(root, 900, 680);

        primaryStage.setTitle("⚡ FitTrack Pro — ABC Fitness Competition");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(750);
        primaryStage.setMinHeight(560);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

