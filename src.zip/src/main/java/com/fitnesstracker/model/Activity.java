package com.fitnesstracker.model;

import java.time.LocalDate;

public class Activity {
    private int id;
    private String employeeName;
    private String activityType;
    private double value;
    private LocalDate activityDate;

    public Activity(int id, String employeeName, String activityType,
                    double value, LocalDate activityDate) {
        this.id = id;
        this.employeeName = employeeName;
        this.activityType = activityType;
        this.value = value;
        this.activityDate = activityDate;
    }

    public int getId() { return id; }
    public String getEmployeeName() { return employeeName; }
    public String getActivityType() { return activityType; }
    public double getValue() { return value; }
    public LocalDate getActivityDate(){ return activityDate; }

    /** Human-readable unit label depending on activity */
    public String getDisplayValue() {
        if ("Running".equals(activityType)) {
            return (int) value + " steps";
        }
        return value + " hrs";
    }

    /** Points calculation */
    public double getPoints() {
        return switch (activityType) {
            case "Running" -> value / 10.0;
            case "Swimming" -> (value / 0.5) * 1200.0;
            case "Workout" -> (value / 1.0) * 1500.0;
            default -> 0;
        };
    }
}
