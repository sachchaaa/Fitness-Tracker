package com.fitnesstracker.controller;

import com.fitnesstracker.DatabaseConnection;
import com.fitnesstracker.model.Activity;
import com.fitnesstracker.model.Employee;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;

import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public class MainController implements Initializable {

    // ── Tab 1 — Add Activity ──────────────────────────────────────
    @FXML private ComboBox<Employee> employeeCombo;
    @FXML private ComboBox<String> activityTypeCombo;
    @FXML private Label valueLabel;
    @FXML private TextField valueField;
    @FXML private DatePicker activityDate;
    @FXML private Label feedbackLabel;

    // ── Tab 2 — View Activities ───────────────────────────────────
    @FXML private ComboBox<String> filterEmployee;
    @FXML private ComboBox<String> filterType;
    @FXML private TableView<Activity> activitiesTable;
    @FXML private TableColumn<Activity, String> colEmployee;
    @FXML private TableColumn<Activity, String> colActivityType;
    @FXML private TableColumn<Activity, String> colValue;
    @FXML private TableColumn<Activity, LocalDate> colDate;
    @FXML private TableColumn<Activity, String> colPoints;

    // ── Tab 3 — Leaderboard ───────────────────────────────────────
    @FXML private VBox leaderboardBox;

    // ── Shared ────────────────────────────────────────────────────
    private final ObservableList<Employee> employees =
            FXCollections.observableArrayList();

    // ═════════════════════════════════════════════════════════════
// INITIALIZE
// ═════════════════════════════════════════════════════════════
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadEmployees();
        setupAddTab();
        setupViewTab();
        buildLeaderboard();
    }

    // ─────────────────────────────────────────────────────────────
// TAB 1 SETUP
// ─────────────────────────────────────────────────────────────
    private void setupAddTab() {
        employeeCombo.setItems(employees);
        activityTypeCombo.setItems(FXCollections.observableArrayList(
                "Running", "Swimming", "Workout"));
        activityDate.setValue(LocalDate.now());
    }

    /** Called when the activity type ComboBox selection changes (onAction in FXML) */
    @FXML
    private void onActivityTypeChanged() {
        String t = activityTypeCombo.getValue();
        if (t == null) return;
        valueLabel.setText(switch (t) {
            case "Running" -> "Number of Steps";
            case "Swimming" -> "Hours Swum";
            case "Workout" -> "Hours Worked Out";
            default -> "Value";
        });
        valueField.setPromptText(switch (t) {
            case "Running" -> "e.g. 5000";
            case "Swimming" -> "e.g. 1.5";
            case "Workout" -> "e.g. 2.0";
            default -> "";
        });
    }

    /** Called when Save Activity button is clicked */
    @FXML
    private void onSaveActivity() {
        feedbackLabel.setText("");
        Employee emp = employeeCombo.getValue();
        String type = activityTypeCombo.getValue();
        String valS = valueField.getText().trim();
        LocalDate date = activityDate.getValue();

        if (emp == null || type == null || valS.isEmpty() || date == null) {
            setFeedback("⚠ Please fill in all fields.", false);
            return;
        }
        try {
            double val = Double.parseDouble(valS);
            if (val <= 0) throw new NumberFormatException();

            String sql =
                    "INSERT INTO activities(employee_id,activity_type,value,activity_date)"
                            + " VALUES(?,?,?,?)";
            try (PreparedStatement ps =
                         DatabaseConnection.getConnection().prepareStatement(sql)) {
                ps.setInt(1, emp.getId());
                ps.setString(2, type);
                ps.setDouble(3, val);
                ps.setDate(4, Date.valueOf(date));
                ps.executeUpdate();
            }
            setFeedback("✅ Activity saved successfully!", true);
            employeeCombo.setValue(null);
            activityTypeCombo.setValue(null);
            valueField.clear();
            valueLabel.setText("Number of Steps");
            activityDate.setValue(LocalDate.now());

        } catch (NumberFormatException ex) {
            setFeedback("⚠ Enter a valid positive number.", false);
        } catch (SQLException ex) {
            setFeedback("❌ DB Error: " + ex.getMessage(), false);
        }
    }

    // ─────────────────────────────────────────────────────────────
// TAB 2 SETUP
// ─────────────────────────────────────────────────────────────
    @SuppressWarnings("unchecked")
    private void setupViewTab() {
// Employee filter dropdown
        filterEmployee.getItems().add("All");
        employees.forEach(e -> filterEmployee.getItems().add(e.getName()));
        filterEmployee.setValue("All");

// Type filter dropdown
        filterType.setItems(FXCollections.observableArrayList(
                "All", "Running", "Swimming", "Workout"));
        filterType.setValue("All");

// Wire columns
        colEmployee.setCellValueFactory(new PropertyValueFactory<>("employeeName"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("activityDate"));

        colActivityType.setCellValueFactory(new PropertyValueFactory<>("activityType"));
        colActivityType.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                String cssClass = switch (item) {
                    case "Running" -> "badge-running";
                    case "Swimming" -> "badge-swimming";
                    case "Workout" -> "badge-workout";
                    default -> "";
                };
                getStyleClass().setAll("table-cell", cssClass);
            }
        });

        colValue.setCellValueFactory(cd ->
                new SimpleStringProperty(cd.getValue().getDisplayValue()));

        colPoints.setCellValueFactory(cd ->
                new SimpleStringProperty(
                        String.format("%.1f", cd.getValue().getPoints())));
        colPoints.setStyle("-fx-text-fill:#a8ff3e;-fx-font-weight:bold;");

// Alternating row colors
        activitiesTable.setRowFactory(tv -> new TableRow<>() {
            @Override protected void updateItem(Activity item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setStyle("-fx-background-color:#161b22;");
                } else {
                    setStyle("-fx-background-color:"
                            + (getIndex() % 2 == 0 ? "#161b22" : "#1c2330") + ";");
                }
            }
        });

        loadActivities(null, null);
    }

    /** Called when Filter button is clicked */
    @FXML
    private void onFilterActivities() {
        String emp = "All".equals(filterEmployee.getValue()) ? null : filterEmployee.getValue();
        String type = "All".equals(filterType.getValue()) ? null : filterType.getValue();
        loadActivities(emp, type);
    }

    /** Called when Reset button is clicked */
    @FXML
    private void onResetFilter() {
        filterEmployee.setValue("All");
        filterType.setValue("All");
        loadActivities(null, null);
    }

    /** Refresh table when tab is selected */
    @FXML
    private void onViewTabSelected() {
        loadActivities(null, null);
    }

    // ─────────────────────────────────────────────────────────────
// TAB 3 SETUP
// ─────────────────────────────────────────────────────────────
    @FXML
    private void onLeaderboardTabSelected() {
        buildLeaderboard();
    }

    @FXML
    private void onRefreshLeaderboard() {
        buildLeaderboard();
    }

    private void buildLeaderboard() {
        leaderboardBox.getChildren().clear();
        List<Map.Entry<String, Double>> top10 = getTop10();

        String[] medals = {"🥇", "🥈", "🥉"};
        String[] rankStyles = {"lb-rank-gold", "lb-rank-silver", "lb-rank-bronze"};
        String[] nameStyles = {"lb-name-top", "lb-name-top", "lb-name-top"};
        String[] ptsStyles = {"lb-pts-top", "lb-pts-top", "lb-pts-top"};
        String[] rowStyles = {"lb-row-gold", "lb-row-silver", "lb-row-bronze"};

        double maxPts = top10.isEmpty() ? 1 : top10.get(0).getValue();

        for (int i = 0; i < top10.size(); i++) {
            Map.Entry<String, Double> entry = top10.get(i);
            boolean isPodium = i < 3;

// Rank label
            Label rankLbl = new Label(isPodium ? medals[i] : String.valueOf(i + 1));
            rankLbl.getStyleClass().add(isPodium ? rankStyles[i] : "lb-rank-normal");
            rankLbl.setMinWidth(44);
            rankLbl.setAlignment(Pos.CENTER);

// Name
            Label nameLbl = new Label(entry.getKey());
            nameLbl.getStyleClass().add(isPodium ? nameStyles[i] : "lb-name-normal");

// Progress bar
            double barPct = entry.getValue() / maxPts;
            Pane barFill = new Pane();
            barFill.setPrefHeight(5);
            barFill.setPrefWidth(200 * barPct);
            barFill.setStyle(
                    "-fx-background-color:" + (isPodium ? "#a8ff3e" : "#4fc3f7")
                            + ";-fx-background-radius:3;"
            );

            VBox nameBox = new VBox(4, nameLbl, barFill);
            HBox.setHgrow(nameBox, Priority.ALWAYS);

// Points
            Label ptsLbl = new Label(String.format("%.0f pts", entry.getValue()));
            ptsLbl.getStyleClass().add(isPodium ? ptsStyles[i] : "lb-pts-normal");

// Row
            HBox row = new HBox(12, rankLbl, nameBox, ptsLbl);
            row.setAlignment(Pos.CENTER_LEFT);
            row.getStyleClass().add(isPodium ? rowStyles[i] : "lb-row-normal");

            leaderboardBox.getChildren().add(row);
        }

        if (top10.isEmpty()) {
            Label empty = new Label("No data yet — start logging activities!");
            empty.setStyle("-fx-text-fill:#484f58;-fx-font-size:14;-fx-font-family:Georgia;");
            leaderboardBox.getChildren().add(empty);
        }
    }

    // ═════════════════════════════════════════════════════════════
// DATABASE HELPERS
// ═════════════════════════════════════════════════════════════
    private void loadEmployees() {
        employees.clear();
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT id,name,department FROM employees ORDER BY name")) {
            while (rs.next())
                employees.add(new Employee(rs.getInt("id"),
                        rs.getString("name"), rs.getString("department")));
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private void loadActivities(String empName, String type) {
        StringBuilder sql = new StringBuilder(
                "SELECT a.id,e.name,a.activity_type,a.value,a.activity_date " +
                        "FROM activities a JOIN employees e ON a.employee_id=e.id WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (empName != null) { sql.append(" AND e.name=?"); params.add(empName); }
        if (type != null) { sql.append(" AND a.activity_type=?"); params.add(type); }
        sql.append(" ORDER BY a.activity_date DESC");

        ObservableList<Activity> list = FXCollections.observableArrayList();
        try (PreparedStatement ps =
                     DatabaseConnection.getConnection().prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) ps.setObject(i + 1, params.get(i));
            ResultSet rs = ps.executeQuery();
            while (rs.next())
                list.add(new Activity(rs.getInt("id"), rs.getString("name"),
                        rs.getString("activity_type"), rs.getDouble("value"),
                        rs.getDate("activity_date").toLocalDate()));
        } catch (SQLException e) { e.printStackTrace(); }
        activitiesTable.setItems(list);
    }

    private List<Map.Entry<String, Double>> getTop10() {
        Map<String, Double> scores = new LinkedHashMap<>();
        String sql =
                "SELECT e.name,a.activity_type,SUM(a.value) AS total " +
                        "FROM activities a JOIN employees e ON a.employee_id=e.id " +
                        "GROUP BY e.name,a.activity_type";
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                String emp = rs.getString("name");
                String t = rs.getString("activity_type");
                double sum = rs.getDouble("total");
                double pts = switch (t) {
                    case "Running" -> sum / 10.0;
                    case "Swimming" -> (sum / 0.5) * 1200.0;
                    case "Workout" -> sum * 1500.0;
                    default -> 0;
                };
                scores.merge(emp, pts, Double::sum);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return scores.entrySet().stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .limit(10).toList();
    }

    // ─────────────────────────────────────────────────────────────
// UTILITY
// ─────────────────────────────────────────────────────────────
    private void setFeedback(String msg, boolean success) {
        feedbackLabel.setText(msg);
        feedbackLabel.setStyle(success
                ? "-fx-text-fill:#a8ff3e;-fx-font-family:Georgia;-fx-font-weight:bold;"
                : "-fx-text-fill:#ff6b6b;-fx-font-family:Georgia;-fx-font-weight:bold;"
        );
    }
}


